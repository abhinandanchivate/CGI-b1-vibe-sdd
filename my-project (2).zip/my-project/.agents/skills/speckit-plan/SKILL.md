---
name: "speckit-plan"
description: "Execute the implementation planning workflow using the plan template to generate design artifacts."
compatibility: "Requires spec-kit project structure with .specify/ directory"
metadata:
  author: "github-spec-kit"
  source: "templates/commands/plan.md"
  version: "1.4.3.dev0"
---


## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Project requirements: Student Grade Calculator (Step 4: Plan)

Added for this project. Apply these together with the procedure in the rest of this file: keep everything the Spec Kit procedure and template require, and add what is asked here. Where they conflict on content, these requirements win. When this command is finished, STOP. Do not run, start or suggest the next command; the human runs it after approving this step.

### Project rules (every step)

```text
NON-NEGOTIABLE RULES FOR YOU (the AI):
1. Do only the current step. When it is done, STOP. Do not run, start or
   suggest the next Spec Kit command; the human runs it after approval.
2. If information is missing or ambiguous, DO NOT assume. Put it under
   "OPEN QUESTIONS" and do not complete that item.
3. Never invent facts, test results, screenshots or approvals. If you did not
   receive real evidence, write "NOT PROVIDED".
4. Do not change an approved artifact. If you think one is wrong, raise it as
   a "CHANGE REQUEST: <artifact> v<n> - <reason>".
5. Follow the Spec Kit skill's own steps for scripts, templates and file
   locations. These instructions add content requirements on top: keep the
   template's required sections AND add what is asked here. Where they
   conflict on content, these instructions win.
6. Read only the files this step needs. Change only the files this step
   produces.

CONVENTIONS:
- IDs: RULE-n (constitution), C-nn (constitution checks), REQ-n (requirements),
  MSG-n (messages), T-nn (spec tests), Q-n (clarify questions),
  TASK-n (tasks; do NOT use Spec Kit's T001 style, it clashes with T-nn),
  A-nn (analysis findings), F-nn (review findings)
- Requirement language: MUST / MUST NOT / SHOULD / MAY (RFC 2119)
- Tests: Given / When / Then, with exact expected strings
- No code unless the step asks for code

WHERE THE APPROVED ARTIFACTS LIVE (Spec Kit locations):
- Constitution: .specify/memory/constitution.md
- Spec, plan, tasks: specs/<feature folder>/spec.md, plan.md, tasks.md
  (the current feature folder is recorded in .specify/feature.json)

STATUS BLOCK: put this at the very top of every artifact you write. The
human fills in approved_by and approved_on and sets status to Approved.
---
status: Draft
version: 0.1
step: <step number>
approved_by:
approved_on:
---
```

### Requirements for this step

```text
Read the constitution and the
APPROVED spec.md. If the spec status is not Approved, stop and say so.

ROLE: You are the architect. Turn the approved spec into a technical plan
(HOW), checked against every constitution rule. Do not write app code.
Do not add features that are not in the spec. Tech: one HTML file,
plain JavaScript, no libraries, no build step, no backend.

PRODUCE (in plan.md, in addition to the template's required sections):
1. File structure (RULE-1): one app file index.html; tests.js separate.
2. UI elements: id, <label> text, input type and inputmode, and why
   (type="text" + inputmode="numeric" so "85.5" and "abc" reach validation).
3. Components: each function's name, inputs, return value, REQ IDs.
   Pure logic (grading, validation, normalising) separate from DOM code.
4. Data flow: submit (button or Enter) -> read -> normalise -> validate
   -> grade -> clear old result -> render. Numbered steps.
5. Rendering rules (RULE-5): textContent only; no innerHTML with user data.
6. Error-handling strategy (RULE-3), including a top-level guard.
7. Accessibility plan (RULE-6): labels, aria-live="polite" result region,
   focus order, contrast values, a word or icon next to colour.
8. Layout plan (RULE-4): single column, max width, font sizes, 44 px
   tap targets, 320 px and landscape behaviour.
9. Browser support notes (RULE-7).
10. Constitution compliance table [Design decision | RULE | Check ID].
11. Spec coverage table [REQ | Plan section]. Every REQ MUST appear.
12. Risks and recorded exceptions.
13. OPEN QUESTIONS.

SELF-CHECK: zero REQs uncovered, zero RULE violations, nothing beyond the
spec. Status block step 4. Then STOP.
```

## Pre-Execution Checks

**Check for extension hooks (before planning)**:
- Check if `.specify/extensions.yml` exists in the project root.
- If it exists, read it and look for entries under the `hooks.before_plan` key
- If the YAML cannot be parsed or is invalid, do not skip silently: tell the user that `.specify/extensions.yml` could not be read (include the parser error) and that no hooks were checked, including any mandatory (`optional: false`) hooks registered there, then continue normally
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing command invocations from hook command names, replace dots (`.`) with hyphens (`-`). For example, `speckit.git.commit` → `/speckit-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```
  - **Mandatory hook** (`optional: false`):
    ```
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session (the invocation may differ from the literal `{command}` id shown above, e.g. a skills-mode agent runs it as `/skill:speckit-...` or `$speckit-...`). Emitting the block alone does not run the hook.
- If no hooks are registered or `.specify/extensions.yml` does not exist, skip silently

## Outline

1. **Setup**: Run `.specify/scripts/bash/setup-plan.sh --json` from repo root and parse JSON for FEATURE_SPEC, IMPL_PLAN, FEATURE_DIR, BRANCH. For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Load context**: Read FEATURE_SPEC and `.specify/memory/constitution.md`. Load IMPL_PLAN template (already copied).

3. **Execute plan workflow**: Follow the structure in IMPL_PLAN template to:
   - Fill Technical Context (mark unknowns as "NEEDS CLARIFICATION")
   - Fill Constitution Check section from constitution
   - Evaluate gates (ERROR if violations unjustified)
   - Phase 0: Generate research.md (resolve all NEEDS CLARIFICATION)
   - Phase 1: Generate data-model.md, contracts/, quickstart.md
   - Re-evaluate Constitution Check post-design

## Mandatory Post-Execution Hooks

**You MUST complete this section before reporting completion to the user.**

Check if `.specify/extensions.yml` exists in the project root.
- If it does not exist, or no hooks are registered under `hooks.after_plan`, skip to the Completion Report.
- If it exists, read it and look for entries under the `hooks.after_plan` key.
- If the YAML cannot be parsed or is invalid, do not skip silently: tell the user that `.specify/extensions.yml` could not be read (include the parser error) and that no hooks were checked, including any mandatory (`optional: false`) hooks registered there, then continue to the Completion Report.
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing command invocations from hook command names, replace dots (`.`) with hyphens (`-`). For example, `speckit.git.commit` → `/speckit-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Mandatory hook** (`optional: false`) — **You MUST emit `EXECUTE_COMMAND:` for each mandatory hook**:
    ```
    ## Extension Hooks

    **Automatic Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session (the invocation may differ from the literal `{command}` id shown above, e.g. a skills-mode agent runs it as `/skill:speckit-...` or `$speckit-...`). Emitting the block alone does not run the hook.
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

## Completion Report

Command ends after Phase 1 design. Report branch, IMPL_PLAN path, and generated artifacts.

## Phases

### Phase 0: Outline & Research

1. **Extract unknowns from Technical Context** above:
   - For each NEEDS CLARIFICATION → research task
   - For each dependency → best practices task
   - For each integration → patterns task

2. **Generate and dispatch research agents**:

   ```text
   For each unknown in Technical Context:
     Task: "Research {unknown} for {feature context}"
   For each technology choice:
     Task: "Find best practices for {tech} in {domain}"
   ```

3. **Consolidate findings** in `research.md` using format:
   - Decision: [what was chosen]
   - Rationale: [why chosen]
   - Alternatives considered: [what else evaluated]

**Output**: research.md with all NEEDS CLARIFICATION resolved

### Phase 1: Design & Contracts

**Prerequisites:** `research.md` complete

1. **Extract entities from feature spec** → `data-model.md`:
   - Entity name, fields, relationships
   - Validation rules from requirements
   - State transitions if applicable

2. **Define interface contracts** (if project has external interfaces) → `/contracts/`:
   - Identify what interfaces the project exposes to users or other systems
   - Document the contract format appropriate for the project type
   - Examples: public APIs for libraries, command schemas for CLI tools, endpoints for web services, grammars for parsers, UI contracts for applications
   - Skip if project is purely internal (build scripts, one-off tools, etc.)

3. **Create quickstart validation guide** → `quickstart.md`:
   - Document runnable validation scenarios that prove the feature works end-to-end
   - Include prerequisites, setup commands, test/run commands, and expected outcomes
   - Use links or references to contracts and data model details instead of duplicating them
   - Do not include full implementation code, model/service/controller bodies, migrations, or complete test suites
   - Keep this artifact as a validation/run guide; implementation details belong in `tasks.md` and the implementation phase

**Output**: data-model.md, /contracts/*, quickstart.md

## Key rules

- Use absolute paths for filesystem operations; use project-relative paths for references in documentation
- ERROR on gate failures or unresolved clarifications

## Done When

- [ ] Plan workflow executed and design artifacts generated
- [ ] Extension hooks dispatched or skipped according to the rules in Mandatory Post-Execution Hooks above
- [ ] Completion reported to user with branch, plan path, and generated artifacts
