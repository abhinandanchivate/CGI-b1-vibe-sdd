---
name: "sdd-test"
description: "Step 8a of the Student Grade Calculator SDD process (after /speckit-implement): prepare spec-based tests and record only real results. Use only when the user runs /sdd-test."
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

Spec Kit has no command for this step, so this skill carries the full instructions. When it is finished, STOP. Do not run or suggest the next step.

## Project rules (every step)

```text
NON-NEGOTIABLE RULES FOR YOU (the AI):
1. Do only the current step. When it is done, STOP. Do not run, start or
   suggest the next Spec Kit command; the human runs it after approval.
2. If information is missing or ambiguous, DO NOT assume. Put it under
   "OPEN QUESTIONS" and do not complete that item.
3. Never invent facts, test results, screenshots or approvals. If you did not
   receive real evidence, write "NOT PROVIDED".
4. Do not change an approved artifact. If you think one is wrong, raise it as
   a "CHANGE REQUEST: <artifact> v<n> - <reason>".
5. Follow the Spec Kit skill's own steps for scripts, templates and file
   locations. These instructions add content requirements on top: keep the
   template's required sections AND add what is asked here. Where they
   conflict on content, these instructions win.
6. Read only the files this step needs. Change only the files this step
   produces.

CONVENTIONS:
- IDs: RULE-n (constitution), C-nn (constitution checks), REQ-n (requirements),
  MSG-n (messages), T-nn (spec tests), Q-n (clarify questions),
  TASK-n (tasks; do NOT use Spec Kit's T001 style, it clashes with T-nn),
  A-nn (analysis findings), F-nn (review findings)
- Requirement language: MUST / MUST NOT / SHOULD / MAY (RFC 2119)
- Tests: Given / When / Then, with exact expected strings
- No code unless the step asks for code

WHERE THE APPROVED ARTIFACTS LIVE (Spec Kit locations):
- Constitution: .specify/memory/constitution.md
- Spec, plan, tasks: specs/<feature folder>/spec.md, plan.md, tasks.md
  (the current feature folder is recorded in .specify/feature.json)

STATUS BLOCK: put this at the very top of every artifact you write. The
human fills in approved_by and approved_on and sets status to Approved.
---
status: Draft
version: 0.1
step: <step number>
approved_by:
approved_on:
---
```

## Step 8a: Functional tests

```text
Read ONLY spec.md and index.html.
You are an independent QA engineer; you did not write this code.
Derive tests from the SPEC, never from the code. Do not edit index.html.

PRODUCE:
1. A manual test script for every T-ID: steps, exact input, exact expected
   string (from the spec's message catalogue).
2. A file review-tests.js in plain JavaScript (no libraries), to be pasted
   into the browser console with index.html open. It calls the pure
   grading and validation logic for every T-ID and prints one line per
   test: "T-nn PASS" or "T-nn FAIL expected=<...> actual=<...>", then a total.
3. A file test-report.md (next to spec.md) with section "8a Spec tests":
   [ID | Input | Expected | Actual | Pass/Fail | Evidence ref],
   every Actual = "NOT RUN".
Do not predict or fill in any Actual value. Then STOP.

---- RESULTS (send as a second message after running the tests) ----
Here is the REAL output from running the tests:
[paste console output and manual results with screenshot file names]

Fill in the 8a table in test-report.md using ONLY this output.
- PASS only if Actual EXACTLY equals Expected (prefixes, capitals,
  spaces, punctuation). Close enough = FAIL.
- Any T-ID missing from the output = NOT RUN = fail.
- Never edit Expected to match Actual.
For each FAIL or NOT RUN: the TASK-n it returns to and the likely cause.
End with "<passed>/<total> spec tests".
```
