---
name: "speckit-tasks"
description: "Generate an actionable, dependency-ordered tasks.md for the feature based on available design artifacts."
compatibility: "Requires spec-kit project structure with .specify/ directory"
metadata:
  author: "github-spec-kit"
  source: "templates/commands/tasks.md"
  version: "1.4.3.dev0"
---


## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Project requirements: Student Grade Calculator (Step 5: Tasks)

Added for this project. Apply these together with the procedure in the rest of this file: keep everything the Spec Kit procedure and template require, and add what is asked here. Where they conflict on content, these requirements win. When this command is finished, STOP. Do not run, start or suggest the next command; the human runs it after approving this step.

### Project rules (every step)

```text
NON-NEGOTIABLE RULES FOR YOU (the AI):
1. Do only the current step. When it is done, STOP. Do not run, start or
   suggest the next Spec Kit command; the human runs it after approval.
2. If information is missing or ambiguous, DO NOT assume. Put it under
   "OPEN QUESTIONS" and do not complete that item.
3. Never invent facts, test results, screenshots or approvals. If you did not
   receive real evidence, write "NOT PROVIDED".
4. Do not change an approved artifact. If you think one is wrong, raise it as
   a "CHANGE REQUEST: <artifact> v<n> - <reason>".
5. Follow the Spec Kit skill's own steps for scripts, templates and file
   locations. These instructions add content requirements on top: keep the
   template's required sections AND add what is asked here. Where they
   conflict on content, these instructions win.
6. Read only the files this step needs. Change only the files this step
   produces.

CONVENTIONS:
- IDs: RULE-n (constitution), C-nn (constitution checks), REQ-n (requirements),
  MSG-n (messages), T-nn (spec tests), Q-n (clarify questions),
  TASK-n (tasks; do NOT use Spec Kit's T001 style, it clashes with T-nn),
  A-nn (analysis findings), F-nn (review findings)
- Requirement language: MUST / MUST NOT / SHOULD / MAY (RFC 2119)
- Tests: Given / When / Then, with exact expected strings
- No code unless the step asks for code

WHERE THE APPROVED ARTIFACTS LIVE (Spec Kit locations):
- Constitution: .specify/memory/constitution.md
- Spec, plan, tasks: specs/<feature folder>/spec.md, plan.md, tasks.md
  (the current feature folder is recorded in .specify/feature.json)

STATUS BLOCK: put this at the very top of every artifact you write. The
human fills in approved_by and approved_on and sets status to Approved.
---
status: Draft
version: 0.1
step: <step number>
approved_by:
approved_on:
---
```

### Requirements for this step

```text
Read the constitution, the
approved spec.md and the approved plan.md.

ROLE: You are a tech lead breaking the plan into AI-sized tasks.
Write them into the tasks.md this skill creates. Name tasks TASK-1,
TASK-2... (not T001), so they never clash with test IDs T-nn.

EACH TASK MUST: fit ONE prompt and ONE human check of about 15 minutes;
have one clear, checkable result; list its dependencies; obey every RULE.

FOR EACH TASK:
- TASK-n: title
- Implements: REQ IDs and plan sections
- Respects: the RULE IDs this task could break if done carelessly
- Depends on: TASK-x
- Deliverable: exactly what is added or changed in which file
- Developer self-check: 1-3 inputs and expected results (cite T-IDs)
- Must not: what to leave untouched, plus each constitution limit that
  applies (e.g. "no external libraries (RULE-1)", "no innerHTML (RULE-5)")

EXPECTED SHAPE (adjust only if the plan demands):
TASK-1 Page skeleton: labelled inputs, button, empty aria-live result area
TASK-2 Normalise and validate inputs (all rules and messages from the spec)
TASK-3 Grade function (bands from the spec)
TASK-4 Render result as text: success card / error card, clear old result
TASK-5 Wire events (click + Enter) and the top-level crash guard
TASK-6 Mobile layout and accessibility styling (contrast, tap targets)
TASK-7 tests.js: automated checks for every T-ID against the pure logic

Formal testing belongs to the reviewer at Step 8; tasks hold only
developer self-checks and the test file.

FINAL CHECKS:
- Coverage table [Plan section | TASK IDs]; no plan item left out
- Constitution table [RULE | TASK IDs]; every code-related RULE appears
- No deliverable conflicts with a RULE; no task needs two prompts;
  dependencies have no cycles
Status block step 5, then OPEN QUESTIONS. Then STOP.
```

## Pre-Execution Checks

**Check for extension hooks (before tasks generation)**:
- Check if `.specify/extensions.yml` exists in the project root.
- If it exists, read it and look for entries under the `hooks.before_tasks` key
- If the YAML cannot be parsed or is invalid, do not skip silently: tell the user that `.specify/extensions.yml` could not be read (include the parser error) and that no hooks were checked, including any mandatory (`optional: false`) hooks registered there, then continue normally
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing command invocations from hook command names, replace dots (`.`) with hyphens (`-`). For example, `speckit.git.commit` → `/speckit-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```
  - **Mandatory hook** (`optional: false`):
    ```
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session (the invocation may differ from the literal `{command}` id shown above, e.g. a skills-mode agent runs it as `/skill:speckit-...` or `$speckit-...`). Emitting the block alone does not run the hook.
- If no hooks are registered or `.specify/extensions.yml` does not exist, skip silently

## Outline

1. **Setup**: Run `.specify/scripts/bash/setup-tasks.sh --json` from repo root and parse FEATURE_DIR, TASKS_TEMPLATE_CONTENT, TASKS_TEMPLATE, and AVAILABLE_DOCS list. `FEATURE_DIR` and `TASKS_TEMPLATE` must be absolute paths when provided. `AVAILABLE_DOCS` is a list of document names/relative paths available under `FEATURE_DIR` (for example `research.md` or `contracts/`). For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Load design documents**: Read from FEATURE_DIR:
   - **Required**: plan.md (tech stack, libraries, structure), spec.md (user stories with priorities)
   - **Optional**: data-model.md (entities), contracts/ (interface contracts), research.md (decisions), quickstart.md (test scenarios)
   - **IF EXISTS**: Load `.specify/memory/constitution.md` for project principles and governance constraints
   - Note: Not all projects have all documents. Generate tasks based on what's available.

3. **Execute task generation workflow**:
   - Load plan.md and extract tech stack, libraries, project structure
   - Load spec.md and extract user stories with their priorities (P1, P2, P3, etc.)
   - If data-model.md exists: Extract entities and constrained fields, including constraints encoded in field types, and map to user stories
   - If contracts/ exists: Map interface contracts to user stories
   - If research.md exists: Extract decisions for setup tasks
   - Generate tasks organized by user story (see Task Generation Rules below)
   - Generate dependency graph showing user story completion order
   - Create parallel execution examples per user story
   - Validate task completeness (each user story has all needed tasks, independently testable)
   - If data-model.md has constrained fields: Verify every constrained field has an explicit, resolving citation to `data-model.md` and its `Entity.field` in at least one implementing task; correct missing or unresolved citations before returning tasks.md

4. **Generate tasks.md**: Use TASKS_TEMPLATE_CONTENT (from the JSON output above) as the structure. For compatibility with older setup scripts that omit TASKS_TEMPLATE_CONTENT, read TASKS_TEMPLATE instead. Fill with:
   - Correct feature name from plan.md
   - Phase 1: Setup tasks (project initialization)
   - Phase 2: Foundational tasks (blocking prerequisites for all user stories)
   - Phase 3+: One phase per user story (in priority order from spec.md)
   - Each phase includes: story goal, independent test criteria, tests (if requested), implementation tasks
   - Final Phase: Polish & cross-cutting concerns
   - All tasks must follow the strict checklist format (see Task Generation Rules below)
   - Clear file paths for each task
   - Dependencies section showing story completion order
   - Parallel execution examples per story
   - Implementation strategy section (MVP first, incremental delivery)

## Mandatory Post-Execution Hooks

**You MUST complete this section before reporting completion to the user.**

Check if `.specify/extensions.yml` exists in the project root.
- If it does not exist, or no hooks are registered under `hooks.after_tasks`, skip to the Completion Report.
- If it exists, read it and look for entries under the `hooks.after_tasks` key.
- If the YAML cannot be parsed or is invalid, do not skip silently: tell the user that `.specify/extensions.yml` could not be read (include the parser error) and that no hooks were checked, including any mandatory (`optional: false`) hooks registered there, then continue to the Completion Report.
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- When constructing command invocations from hook command names, replace dots (`.`) with hyphens (`-`). For example, `speckit.git.commit` → `/speckit-git-commit`.
- For each executable hook, output the following based on its `optional` flag:
  - **Mandatory hook** (`optional: false`) — **You MUST emit `EXECUTE_COMMAND:` for each mandatory hook**:
    ```
    ## Extension Hooks

    **Automatic Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}
    ```
    After emitting the block above you MUST actually invoke the hook and wait for it to finish before continuing. Run it the same way you would run the command yourself in this agent/session (the invocation may differ from the literal `{command}` id shown above, e.g. a skills-mode agent runs it as `/skill:speckit-...` or `$speckit-...`). Emitting the block alone does not run the hook.
  - **Optional hook** (`optional: true`):
    ```
    ## Extension Hooks

    **Optional Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

## Completion Report

Output path to generated tasks.md and summary:
- Total task count
- Task count per user story
- Parallel opportunities identified
- Independent test criteria for each story
- Suggested MVP scope (typically just User Story 1)
- Format validation: Confirm ALL tasks follow the checklist format (checkbox, ID, labels, file paths)

Context for task generation: $ARGUMENTS

The tasks.md should be immediately executable - each task must be specific enough that an LLM can complete it without context beyond the feature's design documents. This does not require copying those documents into task descriptions.

## Task Generation Rules

**CRITICAL**: Tasks MUST be organized by user story to enable independent implementation and testing.

**Tests are OPTIONAL**: Only generate test tasks if explicitly requested in the feature specification or if user requests TDD approach.

### Checklist Format (REQUIRED)

Every task MUST strictly follow this format:

```text
- [ ] [TaskID] [P?] [Story?] Description with file path
```

**Format Components**:

1. **Checkbox**: ALWAYS start with `- [ ]` (markdown checkbox)
2. **Task ID**: Sequential number (T001, T002, T003...) in execution order
3. **[P] marker**: Include ONLY if task is parallelizable (different files, no dependencies on incomplete tasks)
4. **[Story] label**: REQUIRED for user story phase tasks only
   - Format: [US1], [US2], [US3], etc. (maps to user stories from spec.md)
   - Setup phase: NO story label
   - Foundational phase: NO story label
   - User Story phases: MUST have story label
   - Polish phase: NO story label
5. **Description**: Clear action with exact file path

**Examples**:

- ✅ CORRECT: `- [ ] T001 Create project structure per implementation plan`
- ✅ CORRECT: `- [ ] T005 [P] Implement authentication middleware in src/middleware/auth.py`
- ✅ CORRECT: `- [ ] T012 [P] [US1] Create User model in src/models/user.py`
- ✅ CORRECT: `- [ ] T014 [US1] Implement UserService in src/services/user_service.py`
- ❌ WRONG: `- [ ] Create User model` (missing ID and Story label)
- ❌ WRONG: `T001 [US1] Create model` (missing checkbox)
- ❌ WRONG: `- [ ] [US1] Create User model` (missing Task ID)
- ❌ WRONG: `- [ ] T001 [US1] Create model` (missing file path)

### Task Organization

1. **From User Stories (spec.md)** - PRIMARY ORGANIZATION:
   - Each user story (P1, P2, P3...) gets its own phase
   - Map all related components to their story:
     - Models needed for that story
     - Services needed for that story
     - Interfaces/UI needed for that story
     - If tests requested: Tests specific to that story
   - Mark story dependencies (most stories should be independent)

2. **From Contracts**:
   - Map each interface contract → to the user story it serves
   - If tests requested: Each interface contract → contract test task [P] before implementation in that story's phase

3. **From Data Model**:
   - Map each entity to the user story(ies) that need it
   - If entity serves multiple stories: Put in earliest story or Setup phase
   - Relationships → service layer tasks in appropriate story phase
   - data-model.md is the canonical source for field constraints (max/min length, nullable/required, enum values, validation rules), including constraints encoded in field types
   - Cite each constrained field explicitly using `data-model.md` and its exact `Entity.field` in the implementing task description; plain text or links are acceptable when both are unambiguous. A shared implementing task may cite multiple fields
   - Associate each cited field explicitly with its canonical definition. A field mention elsewhere in the task is not a citation merely because other fields in that task cite data-model.md
   - Use citations instead of duplicated constraint prose. Do not require verbatim copies of constraints in tasks.md. Do not restate unchanged constraints; state a constraint only when the task adds to or narrows the canonical rule, and identify that task-specific addition or narrowing. Task-specific constraints MUST NOT contradict the canonical field definition

4. **From Setup/Infrastructure**:
   - Shared infrastructure → Setup phase (Phase 1)
   - Foundational/blocking tasks → Foundational phase (Phase 2)
   - Story-specific setup → within that story's phase

### Phase Structure

- **Phase 1**: Setup (project initialization)
- **Phase 2**: Foundational (blocking prerequisites - MUST complete before user stories)
- **Phase 3+**: User Stories in priority order (P1, P2, P3...)
  - Within each story: Tests (if requested) → Models → Services → Endpoints → Integration
  - Each phase should be a complete, independently testable increment
- **Final Phase**: Polish & Cross-Cutting Concerns

## Done When

- [ ] tasks.md generated with all phases, task IDs, and file paths
- [ ] Extension hooks dispatched or skipped according to the rules in Mandatory Post-Execution Hooks above
- [ ] Completion reported to user with task count, story breakdown, and MVP scope
