---
name: "sdd-release"
description: "Step 8c of the Student Grade Calculator SDD process: prepare the release decision from real evidence. Use only when the user runs /sdd-release."
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

Spec Kit has no command for this step, so this skill carries the full instructions. When it is finished, STOP. Do not run or suggest the next step.

## Project rules (every step)

```text
NON-NEGOTIABLE RULES FOR YOU (the AI):
1. Do only the current step. When it is done, STOP. Do not run, start or
   suggest the next Spec Kit command; the human runs it after approval.
2. If information is missing or ambiguous, DO NOT assume. Put it under
   "OPEN QUESTIONS" and do not complete that item.
3. Never invent facts, test results, screenshots or approvals. If you did not
   receive real evidence, write "NOT PROVIDED".
4. Do not change an approved artifact. If you think one is wrong, raise it as
   a "CHANGE REQUEST: <artifact> v<n> - <reason>".
5. Follow the Spec Kit skill's own steps for scripts, templates and file
   locations. These instructions add content requirements on top: keep the
   template's required sections AND add what is asked here. Where they
   conflict on content, these instructions win.
6. Read only the files this step needs. Change only the files this step
   produces.

CONVENTIONS:
- IDs: RULE-n (constitution), C-nn (constitution checks), REQ-n (requirements),
  MSG-n (messages), T-nn (spec tests), Q-n (clarify questions),
  TASK-n (tasks; do NOT use Spec Kit's T001 style, it clashes with T-nn),
  A-nn (analysis findings), F-nn (review findings)
- Requirement language: MUST / MUST NOT / SHOULD / MAY (RFC 2119)
- Tests: Given / When / Then, with exact expected strings
- No code unless the step asks for code

WHERE THE APPROVED ARTIFACTS LIVE (Spec Kit locations):
- Constitution: .specify/memory/constitution.md
- Spec, plan, tasks: specs/<feature folder>/spec.md, plan.md, tasks.md
  (the current feature folder is recorded in .specify/feature.json)

STATUS BLOCK: put this at the very top of every artifact you write. The
human fills in approved_by and approved_on and sets status to Approved.
---
status: Draft
version: 0.1
step: <step number>
approved_by:
approved_on:
---
```

## Step 8c: PR approval and release

```text
Read the status blocks of the
constitution, spec.md, plan.md and tasks.md; the analysis result I paste;
test-report.md; and sdd/prompt-log.md (if present). Use only this evidence; anything
missing = "NOT PROVIDED". Write the result to release.md next to spec.md.

PRODUCE:
1. PR description: summary, REQ IDs, TASK IDs, files changed, artifact
   versions.
2. Sign-off table [Step | Artifact + version | Approver | Date | Evidence].
   Any step without approver or date -> REJECT.
3. Test summary, counted separately: spec tests (8a) x/y; constitution
   checks (8b) x/y; open Blockers / Majors / Minors.
4. Evidence index: each screenshot mapped to a T-ID or C-ID.
5. Version check: were 8a and 8b run on the commit being released?
   (commit ID I tested: [paste]). If not -> REJECT.
6. Release notes for teachers, plain language.
7. Release record: tag (v1.0.0), where published, rollback plan.
8. Known gaps carried forward.
9. Decision: APPROVE or REJECT with reasons. APPROVE only if every step is
   signed off, every test and check has real evidence, and no Blocker or
   Major is open. Then STOP.
```
