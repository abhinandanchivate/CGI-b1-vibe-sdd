---
name: "sdd-review"
description: "Step 8b of the Student Grade Calculator SDD process: prepare the constitution checklist and record only real results. Use only when the user runs /sdd-review."
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

Spec Kit has no command for this step, so this skill carries the full instructions. When it is finished, STOP. Do not run or suggest the next step.

## Project rules (every step)

```text
NON-NEGOTIABLE RULES FOR YOU (the AI):
1. Do only the current step. When it is done, STOP. Do not run, start or
   suggest the next Spec Kit command; the human runs it after approval.
2. If information is missing or ambiguous, DO NOT assume. Put it under
   "OPEN QUESTIONS" and do not complete that item.
3. Never invent facts, test results, screenshots or approvals. If you did not
   receive real evidence, write "NOT PROVIDED".
4. Do not change an approved artifact. If you think one is wrong, raise it as
   a "CHANGE REQUEST: <artifact> v<n> - <reason>".
5. Follow the Spec Kit skill's own steps for scripts, templates and file
   locations. These instructions add content requirements on top: keep the
   template's required sections AND add what is asked here. Where they
   conflict on content, these instructions win.
6. Read only the files this step needs. Change only the files this step
   produces.

CONVENTIONS:
- IDs: RULE-n (constitution), C-nn (constitution checks), REQ-n (requirements),
  MSG-n (messages), T-nn (spec tests), Q-n (clarify questions),
  TASK-n (tasks; do NOT use Spec Kit's T001 style, it clashes with T-nn),
  A-nn (analysis findings), F-nn (review findings)
- Requirement language: MUST / MUST NOT / SHOULD / MAY (RFC 2119)
- Tests: Given / When / Then, with exact expected strings
- No code unless the step asks for code

WHERE THE APPROVED ARTIFACTS LIVE (Spec Kit locations):
- Constitution: .specify/memory/constitution.md
- Spec, plan, tasks: specs/<feature folder>/spec.md, plan.md, tasks.md
  (the current feature folder is recorded in .specify/feature.json)

STATUS BLOCK: put this at the very top of every artifact you write. The
human fills in approved_by and approved_on and sets status to Approved.
---
status: Draft
version: 0.1
step: <step number>
approved_by:
approved_on:
---
```

## Step 8b: Edge cases and constitution review

```text
Read the constitution, spec.md and
index.html. You did not write this code. Do not edit index.html.

1: Add a section "8b Constitution checks" to test-report.md with a
checklist [Check ID | Rule | Steps | Expected | Actual = NOT RUN | Evidence ref]:
PART A, one row per check ID:
- RULE-1: search the file for <script src, <link, @import, url(, fetch,
  XMLHttpRequest, external fonts
- RULE-3: hostile inputs; zero console errors, readable message shown
- RULE-4: 375 px and 320 px, landscape, on-screen keyboard, no
  horizontal scroll, 44 px tap targets
- RULE-5: name "<img src=x onerror=alert(1)>" shows as text, no alert;
  no innerHTML with user data in the code
- RULE-6: keyboard only (Tab, Enter), screen reader announces result,
  labels, contrast, meaning not by colour alone
- RULE-7: core tests in each supported browser
PART B, exploratory: very long name, emoji name, pasted marks with spaces,
double-click, Enter in each field, "-0", "Infinity", "1e2", "85,5",
invalid submit after a valid one, 200% zoom.
Then STOP and wait for my real results.

---- RESULTS (second message) ----
Here are my REAL results: [paste]
Fill in Actual and Pass/Fail from these ONLY. Then list findings
[F-nn | Finding | Severity (Blocker/Major/Minor) | RULE or REQ |
 Returns to Step 7 (code), Step 3 (spec gap) or Step 1 (rule)].
Propose new REQs/tests for spec gaps but do not add them.
End with "<passed>/<total> constitution checks".
```
