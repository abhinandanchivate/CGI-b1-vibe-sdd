---
status: Draft
version: 0.1
step: 1
approved_by:
approved_on:
---

<!--
### Sync Impact Report
- Version change: Initial unpopulated template -> v0.1 (Draft)
- List of modified principles:
  - PRINCIPLE_1_NAME -> RULE-1 (Single-file HTML/CSS/JS delivery)
  - PRINCIPLE_2_NAME -> RULE-2 (Spec with Done-when tests written before code)
  - PRINCIPLE_3_NAME -> RULE-3 (Friendly errors and crash resilience)
  - PRINCIPLE_4_NAME -> RULE-4 (Mobile screen responsiveness)
  - PRINCIPLE_5_NAME -> RULE-5 (User input rendered strictly as text)
  - Added RULE-6 (Accessibility standards)
  - Added RULE-7 (Supported browsers)
- Added sections:
  - Core Principles Table
  - Exceptions Process
  - Scope Note
  - Governance
  - Open Questions
- Removed sections:
  - Template placeholder sections (SECTION_2_NAME, SECTION_3_NAME)
- Follow-up TODOs:
  - Q-1: Confirm exact supported browser list for RULE-7
-->

# Student Grade Calculator Constitution

## Core Principles

The following non-negotiable rules govern all design, implementation, and verification activities for the Student Grade Calculator project. Every feature and artifact must comply with these principles.

| ID | Rule | Rationale | Measurable criteria | Verification | Step | Check ID |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **RULE-1** | The application MUST be delivered as a single standalone HTML file (`index.html`) containing all CSS within `<style>` tags and all JavaScript within `<script>` tags. The application MUST NOT link to or load external libraries, frameworks, CDNs, external stylesheets, external fonts, or remote assets, and MUST NOT make outbound network requests. Test harnesses MAY live in separate test files. | Guarantees zero-dependency portability, offline functionality, zero-friction distribution, and freedom from third-party network outages or vulnerabilities. | 1. Deliverable is exactly 1 file named `index.html`.<br>2. Zero `<link rel="stylesheet">`, zero external `<script src="...">`, zero `@import`, zero `@font-face` referencing remote URLs.<br>3. Zero outbound network calls (`fetch`, `XMLHttpRequest`, `sendBeacon`, `WebSocket`).<br>4. DevTools Network panel records 0 network requests when loaded offline. | 1. Open `index.html` in browser with Network set to "Offline".<br>2. Confirm page loads completely and is functional.<br>3. Inspect source; verify all CSS is in `<style>` and JS in `<script>`.<br>4. Search source for `http://`, `https://`, `//`, `fetch(`, `XMLHttpRequest`, `WebSocket`; verify 0 hits. | Step 8b | C-01 |
| **RULE-2** | Every feature MUST have an approved specification (`spec.md`) containing verifiable "Done-when" acceptance tests (using RFC 2119 keywords and Given/When/Then format with exact expected strings) written and approved BEFORE production code is authored. | Prevents scope ambiguity, aligns implementation with explicit requirements, and enforces a test-driven development workflow. | 1. `specs/<feature>/spec.md` exists and contains a "Done-when" test section with IDs `T-01`, `T-02`, etc., in Given/When/Then format with exact string assertions.<br>2. Specification status block has `status: Approved` with `approved_by` and `approved_on` completed prior to code generation in `index.html`. | 1. Open `specs/<feature>/spec.md` and verify each feature requirement maps to Given/When/Then test cases with exact expected strings.<br>2. Inspect commit history or artifact timestamps to confirm `spec.md` approval preceded code edits in `index.html`. | Step 3 | C-02 |
| **RULE-3** | The application MUST handle all invalid, boundary, and unexpected inputs gracefully with friendly, actionable error messages and MUST NOT crash or emit uncaught exceptions under any circumstance. | Delivers a resilient, beginner-friendly experience that guides students to correct mistakes without confusion or loss of state. | 1. Error messages use plain language, clearly stating what is wrong AND how to fix it.<br>2. Error messages and UI outputs MUST NEVER display `NaN`, `undefined`, `null`, `[object Object]`, or raw runtime stack traces.<br>3. Zero uncaught runtime errors in browser console (`window.onerror` / `console.error`) across all inputs, including empty, negative, non-numeric, boundary (>100), and rapid inputs. | 1. Open browser DevTools Console.<br>2. Submit empty fields, non-numeric strings ("abc"), negative numbers ("-1"), numbers exceeding 100 ("101"), special characters, and repeated rapid clicks.<br>3. Verify UI displays plain-language error explaining what is wrong and how to fix it.<br>4. Verify UI does not show "NaN", "undefined", "null", or stack traces.<br>5. Verify DevTools Console shows 0 uncaught exceptions. | Step 8b | C-03 |
| **RULE-4** | The application layout and interactive elements MUST be fully responsive, legible, and operational on mobile viewports down to 320 px width without horizontal scrolling. | Ensures students and educators on smartphones can utilize the calculator without layout breakage or awkward zooming. | 1. Fully usable at viewport widths of 375 px and 320 px in responsive emulation mode.<br>2. Zero horizontal scrolling (`document.documentElement.scrollWidth <= window.innerWidth`).<br>3. All touch targets (buttons, inputs) have a minimum bounding box size of 44 x 44 px.<br>4. All body, label, and input text has a computed `font-size` of at least 16 px. | 1. Open browser DevTools Device Toolbar and set viewport width to 375 px, then 320 px.<br>2. Verify all elements are visible without horizontal scrolling (`scrollWidth == clientWidth`).<br>3. Inspect buttons and form inputs; verify computed height and width are >= 44 px.<br>4. Inspect text elements; verify computed `font-size` is >= 16 px. | Step 8b | C-04 |
| **RULE-5** | All user-supplied input and derived values MUST be rendered into the DOM strictly as text content and MUST NOT be rendered as unescaped HTML. | Eliminates Cross-Site Scripting (XSS) and DOM injection vulnerabilities. | 1. Zero usage of `.innerHTML`, `.outerHTML`, or `document.write` to render user data or derived values.<br>2. Dynamic text output uses `textContent`, `innerText`, or `document.createTextNode`.<br>3. Submitting HTML payloads (e.g. `<script>alert(1)</script>`, `<img src=x onerror=alert(1)>`) renders the string literally on screen without executing scripts or injecting HTML elements. | 1. Search source code for `.innerHTML`, `.outerHTML`, and `document.write`; verify none inject user data.<br>2. Input `<script>alert('xss')</script>` and `<img src=x onerror=alert(1)>` into student name and score fields.<br>3. Submit calculation; verify payload appears as literal plain text and no JavaScript executes / no alerts trigger. | Step 8b | C-05 |
| **RULE-6** | The application MUST be accessible according to WCAG 2.1 AA standards: every input MUST have an explicitly associated `<label>`, all functionality MUST be keyboard-operable with `Enter` submitting calculations, dynamic results MUST be announced to screen readers via `aria-live`, color contrast MUST be at least 4.5:1, and meaning MUST NOT be conveyed by color alone. | Ensures equitable, independent usability for all users, including those relying on screen readers, keyboard navigation, or with visual impairments. | 1. Every `<input>` has a dedicated `<label>` with a matching `for` attribute referencing the input's `id`.<br>2. Pressing `Enter` in any input field triggers calculation.<br>3. Full keyboard operability via `Tab` / `Shift+Tab` / `Enter` with visible `:focus-visible` styling on all interactive controls.<br>4. The result and error container possesses `aria-live="polite"` (or `role="status"` / `role="alert"`).<br>5. Text-to-background contrast ratio is at least 4.5:1 (3:1 for large text >= 18pt or 14pt bold).<br>6. Results and status indicators include explicit text or icons (e.g., "Pass", "Fail", "Grade: A") and never rely on color alone. | 1. Inspect DOM to verify every `<input>` has an associated `<label for="...">`.<br>2. Inspect result container for `aria-live="polite"` or `role="status"`.<br>3. Navigate entirely using `Tab` and `Shift+Tab`; verify visible focus indicators.<br>4. Type a valid score and press `Enter`; verify calculation executes.<br>5. Use DevTools contrast picker to verify contrast >= 4.5:1 for all text.<br>6. Inspect result display; verify status/grades are communicated through text/labels, not color alone. | Step 8b | C-06 |
| **RULE-7** | The application MUST function correctly, render identically without visual defects, and execute all calculations accurately across all officially supported browsers. | Guarantees consistent grading results and uniform presentation across different student and teacher devices. | Exact list of supported browsers is pending confirmation (see OPEN QUESTIONS Q-1). Candidate baseline: Latest stable Google Chrome on Android, latest stable Google Chrome on Desktop, and latest stable Microsoft Edge on Desktop.<br>Across all supported browsers: zero console errors, zero layout breakages, and 100% identical calculation results. | 1. Open `index.html` in each approved browser.<br>2. Execute baseline calculation test cases (e.g., score 85 -> Grade B, boundary scores 0 and 100, invalid inputs).<br>3. Confirm identical visual appearance, responsive layout, and exact result strings across all browsers.<br>4. Confirm zero errors in the console of each browser. | Step 8b | C-07 |

## Exceptions Process

All rules in this Constitution are non-negotiable by default. In rare situations where technical or business realities necessitate an exception, the following formal process must be adhered to:

1. **Authority**: Only the Lead Software Architect or designated Project Owner (a named human) has the authority to waive a rule. AI agents, developers, or contributors MUST NOT grant exceptions.
2. **Recording**: Any approved exception must be documented directly in this document under an "Active Exceptions Log" table. Each entry must record:
   - **Exception ID**: Sequential identifier (e.g. `EXC-01`).
   - **Rule ID**: The specific rule being waived (`RULE-1` through `RULE-7`).
   - **Justification**: The specific technical or functional justification requiring the exception.
   - **Approved By**: Full name of the human approver.
   - **Approval Date**: ISO date `YYYY-MM-DD`.
   - **Mitigation**: Compensating control or safeguard applied during the waiver period.
   - **Expiry**: Specific release milestone or calendar date (maximum 30 days or one release cycle).
3. **Expiry and Sunset**: Exceptions automatically expire upon reaching their designated expiry date or milestone. Expired exceptions that have not been re-reviewed and formally renewed automatically revert to active rule violations.

### Active Exceptions Log

| Exception ID | Rule ID | Justification | Approved By | Approval Date | Mitigation | Expiry |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| *None* | N/A | No active exceptions. | N/A | N/A | N/A | N/A |

## Scope Note

To maintain clear separation between governance and feature implementation:

- **What belongs in the Constitution**: Permanent, cross-cutting architectural principles, non-negotiable quality constraints, accessibility standards, security mandates, technology boundaries, and governance procedures that apply to ALL features and releases across the lifecycle of the project.
- **What belongs in a Feature Specification (`spec.md`)**: Feature-specific user stories, functional requirements (e.g. grading curves, boundary score thresholds, weightings), input field definitions, exact error message strings, specific UI element placements, and feature acceptance test cases.

## Governance

This Constitution represents the highest-priority technical authority for the Student Grade Calculator project and supersedes any conflicting informal conventions, preferences, or individual instructions.

- **Amendment Procedure**: Amendments to this document require an explicit proposal, documentation of rationale in a Sync Impact Report, incrementing the version number according to Semantic Versioning, and formal approval by the designated human project authority.
- **Versioning Policy**: Semantic Versioning (`MAJOR.MINOR.PATCH`) is enforced:
  - `MAJOR`: Incompatible governance changes, removal of rules, or fundamental redefinition of architectural constraints.
  - `MINOR`: Addition of new rules, new quality sections, or materially expanded criteria.
  - `PATCH`: Clarifications, wording improvements, non-semantic refinements, or typo fixes.
- **Compliance Review Expectations**: Compliance is verified systematically at explicit lifecycle gates:
  - `RULE-2` is verified at **Step 3** prior to implementation approval.
  - `RULE-1`, `RULE-3`, `RULE-4`, `RULE-5`, `RULE-6`, and `RULE-7` are verified at **Step 8b** via the formal Constitution Review checklist.

**Version**: 0.1 (Draft) | **Ratified**: Pending Approval | **Last Amended**: 2026-11-20

## Open Questions

- **Q-1: Supported Browsers Specification (RULE-7)**:
  - **Issue**: Starting RULE-7 contained an unedited placeholder (`>>> EDIT ME before running, e.g. latest Chrome on Android, latest Chrome and Edge on desktop <<<`).
  - **Impact**: The measurable criteria and verification targets for RULE-7 cannot be finalized without knowing the exact target browser and OS matrix.
  - **Candidate Recommendation**: Latest stable Google Chrome on Android, latest stable Google Chrome on Desktop, and latest stable Microsoft Edge on Desktop.
  - **Action Required**: The human approver must confirm or edit the supported browser list when approving this constitution.
